import BalanceCard from "../components/BalanceCard";
import Deposit from "../components/Deposit";
import Withdraw from "../components/Withdraw";

export default function Dashboard() {
  return (
    <div>
      <BalanceCard balance={10000} />
      <Deposit />
      <Withdraw />
    </div>
  );
}
