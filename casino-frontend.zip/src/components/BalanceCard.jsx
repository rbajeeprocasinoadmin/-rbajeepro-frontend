export default function BalanceCard({ balance }) {
  return (
    <div>
      <h3>Balance</h3>
      <h1>৳ {balance}</h1>
    </div>
  );
}
