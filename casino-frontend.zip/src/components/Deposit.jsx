export default function Deposit() {
  return (
    <div>
      <input placeholder="Amount" />
      <button>Deposit</button>
    </div>
  );
}
