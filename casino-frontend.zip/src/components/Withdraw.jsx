export default function Withdraw() {
  return (
    <div>
      <input placeholder="Amount" />
      <input placeholder="Number" />
      <button>Withdraw</button>
    </div>
  );
}
